import React from "react";
import { useCart } from "@/components/CartContext";
import Button from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Link from "next/link";

const products = [
  { id: 1, name: "Product A", price: 30 },
  { id: 2, name: "Product B", price: 45 },
  { id: 3, name: "Product C", price: 60 },
];

export default function Home() {
  const { cart, addToCart } = useCart();

  return (
    <div className="space-y-4">
      {products.map((product) => (
        <Card key={product.id} className="bg-white p-4">
          <CardContent>
            <h2 className="text-xl font-bold">{product.name}</h2>
            <p>${product.price}</p>
            <Button onClick={() => addToCart(product)}>Add to Cart</Button>
          </CardContent>
        </Card>
      ))}
      <div className="mt-4">
        <p>Total items in cart: {cart.length}</p>
        <Link href="/checkout" className="underline text-blue-600">Go to Checkout</Link>
      </div>
    </div>
  );
}