import React from "react";
import { useCart } from "@/components/CartContext";

export default function Checkout() {
  const { cart, clearCart } = useCart();
  const total = cart.reduce((acc, item) => acc + item.price, 0);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Checkout</h1>
      <ul className="mb-4">
        {cart.map((item, index) => (
          <li key={index}>
            {item.name} - ${item.price}
          </li>
        ))}
      </ul>
      <p className="font-bold">Total: ${total}</p>
      <button
        className="mt-4 px-4 py-2 bg-green-500 text-white rounded"
        onClick={clearCart}
      >
        Confirm Purchase
      </button>
    </div>
  );
}