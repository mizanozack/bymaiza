import React from "react";

export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-khaki text-gray-800 p-4">
      <header className="text-3xl font-bold mb-4 text-center">Bymaiza.cart</header>
      <main>{children}</main>
    </div>
  );
}