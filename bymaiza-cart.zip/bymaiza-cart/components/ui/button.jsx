import React from "react";

export default function Button({ children, onClick }) {
  return (
    <button
      className="bg-white text-black px-4 py-2 rounded-md shadow hover:bg-gray-100"
      onClick={onClick}
    >
      {children}
    </button>
  );
}